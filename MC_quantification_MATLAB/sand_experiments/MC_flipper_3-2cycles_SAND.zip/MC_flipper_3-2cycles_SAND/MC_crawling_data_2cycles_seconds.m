%% Initialization
% Load data
load("/MATLAB Drive/MC_flipper_3-2cycles_SAND/myStruct12.mat");
myStruct12.name = 'Flipper_data_sand_3cycles';

% Define initial min/max values
position_X_min = 0; 
position_X_max = 289.13;
load_min = 0; 
load_max = 256;

% Get the max/min values of position and load data
position_X_min = min(myStruct12.motor2_position_X_12cycles);
position_X_max = max(myStruct12.motor2_position_X_12cycles);
load_min = min(myStruct12.motor2_load_12cycles);
load_max = max(myStruct12.motor2_load_12cycles);

%% Discretise Test
bins = 370;  % Number of bins for discretization

% Discretize position and load data
myStruct12.discrete_position = discretiseMatrix(myStruct12.motor2_position_X_12cycles, ...
    'min', position_X_min, 'max', position_X_max, 'bins', bins);
myStruct12.discrete_load = discretiseMatrix(myStruct12.motor2_load_12cycles, ...
    'min', load_min, 'max', load_max, 'bins', bins);

%% Run MC quantification
myStruct12.w2 = myStruct12.discrete_position(2:end,:);
myStruct12.w1 = myStruct12.discrete_position(1:end-1,:);
myStruct12.a1 = myStruct12.discrete_load(1:end-1,:);

% Compute MC values
myStruct12.mcw = MC_W1(myStruct12.w2, myStruct12.w1, myStruct12.a1);
myStruct12.mcd = MC_W1_dynamic(myStruct12.w2, myStruct12.w1, myStruct12.a1);

%% Plotting Load and Smooth MC for the First Two Cycles with Dual Y-Axes
figure('Position', [100, 100, 800, 300]);

% Define the range for the first two cycles
cycle12_range = 33:96;

% Plot Smooth MC on the left y-axis
yyaxis left;
plot(smooth(myStruct12.mcd(cycle12_range)), 'DisplayName', 'Smooth MC', 'Color', 'b');
ylabel('Smooth MC Value');
xlabel('Time (s)');  % Update label to indicate time in seconds
title('(A) Sand - Active ');

% Plot Load on the right y-axis
yyaxis right;
plot(myStruct12.discrete_load(cycle12_range), 'DisplayName', 'Load', 'Color', 'r');
ylabel('Load Value');

% Mark the boundary between Cycle 1 and Cycle 2
xline(32, '--k', 'HandleVisibility', 'off'); % End of Cycle 1
xline(64, '--k', 'HandleVisibility', 'off'); % End of Cycle 2

% Set x-axis limit to end at the last data point
xlim([1 64]);

% Modify x-axis labels to show current time steps divided by 2
xticks(1:10:64);  % Set appropriate tick intervals for readability
xticklabels(arrayfun(@(x) sprintf('%.1f', x/2), 1:10:64, 'UniformOutput', false));

% Adjust y-axis limits for left y-axis to allow space for labels
yyaxis left; % Activate left y-axis
ylim_left = ylim; % Get current y-axis limits
ylim([ylim_left(1), ylim_left(2) * 1.1]); % Expand top limit by 10%

% Add labels for Cycle 1 and Cycle 2 at the center of each boundary
text(16.5, ylim_left(2) * 1.05, 'Cycle 1', ...
    'HorizontalAlignment', 'center', 'Color', 'k', 'FontSize', 10, 'FontWeight', 'bold');
text(48, ylim_left(2) * 1.05, 'Cycle 2', ...
    'HorizontalAlignment', 'center', 'Color', 'k', 'FontSize', 10, 'FontWeight', 'bold');

% Display the plot
hold off;
