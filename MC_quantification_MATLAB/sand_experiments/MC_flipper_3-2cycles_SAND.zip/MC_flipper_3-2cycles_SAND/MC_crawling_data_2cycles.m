%% Initialization
clear;

% Load data
load("/MATLAB Drive/MC_flipper_3cycles_SAND/myStruct12.mat");
myStruct12.name = 'Flipper_data_sand_3cycles';

% Define initial min/max values
position_X_min = 0; 
position_X_max = 289.13;
load_min = 0; 
load_max = 256;

% Get the max/min values of position and load data
position_X_min = min(myStruct12.motor2_position_X_12cycles);
position_X_max = max(myStruct12.motor2_position_X_12cycles);
load_min = min(myStruct12.motor2_load_12cycles);
load_max = max(myStruct12.motor2_load_12cycles);

%% Discretise Test
bins = 370;  % Number of bins for discretization

% Discretize position and load data
myStruct12.discrete_position = discretiseMatrix(myStruct12.motor2_position_X_12cycles, ...
    'min', position_X_min, 'max', position_X_max, 'bins', bins);
myStruct12.discrete_load = discretiseMatrix(myStruct12.motor2_load_12cycles, ...
    'min', load_min, 'max', load_max, 'bins', bins);

%% Run MC quantification
myStruct12.w2 = myStruct12.discrete_position(2:end,:);
myStruct12.w1 = myStruct12.discrete_position(1:end-1,:);
myStruct12.a1 = myStruct12.discrete_load(1:end-1,:);

% Compute MC values
myStruct12.mcw = MC_W1(myStruct12.w2, myStruct12.w1, myStruct12.a1);
myStruct12.mcd = MC_W1_dynamic(myStruct12.w2, myStruct12.w1, myStruct12.a1);

%% Plotting Position, Load, and MC for the First Two Cycles
figure('Position', [100, 100, 800, 600]);

% Define the range for the first two cycles
cycle12_range = 33:96;

% Adjusted x-axis values by dividing by 2 for time
time_steps = (cycle12_range) / 2;

% Plot discrete position and load for the first two cycles
subplot(2,1,1);
plot(time_steps, myStruct12.discrete_position(cycle12_range), 'DisplayName', 'Position', 'Color', 'b');
hold on;
plot(time_steps, myStruct12.discrete_load(cycle12_range), 'DisplayName', 'Load', 'Color', 'r');
xlabel('Time (s)');  % Updated x-label
ylabel('Value');
title('Position and Load - 2 cycles');
legend('NumColumns', 1, 'Location', 'northeast', 'Box', 'off');

% Mark the boundary between Cycle 1 and Cycle 2
xline(32 / 2, '--k', 'HandleVisibility', 'off'); % End of Cycle 1
xline(64 / 2, '--k', 'HandleVisibility', 'off'); % End of Cycle 2

% Add labels for Cycle 1 and Cycle 2
text(16.5 / 2, max(myStruct12.discrete_position(cycle12_range)) * 0.9, 'Cycle 1', 'HorizontalAlignment', 'center');
text(48 / 2, max(myStruct12.discrete_position(cycle12_range)) * 0.9, 'Cycle 2', 'HorizontalAlignment', 'center');

% Set x-axis limit to end at the last data point
xlim([1 / 2 64 / 2]);  % Updated limits
hold off;

% Plot MC values with smoothing for the first two cycles
subplot(2,1,2);
plot(time_steps, myStruct12.mcd(cycle12_range), 'DisplayName', 'Actual MC', 'Color', 'b');
hold on;
plot(time_steps, smooth(myStruct12.mcd(cycle12_range)), 'DisplayName', 'Smooth MC', 'Color', 'g');
xlabel('Time (s)');  % Updated x-label
ylabel('MC Value');
title('MC_Water - 2 cycles');
legend('NumColumns', 1, 'Location', 'northeast', 'Box', 'off');

% Mark the boundary between Cycle 1 and Cycle 2 in the MC plot
xline(32 / 2, '--k', 'HandleVisibility', 'off'); % End of Cycle 1
xline(64 / 2, '--k', 'HandleVisibility', 'off'); % End of Cycle 2

% Add labels for Cycle 1 and Cycle 2 in the MC plot
text(16.5 / 2, max(myStruct12.mcd(cycle12_range)) * 0.9, 'Cycle 1', 'HorizontalAlignment', 'center');
text(48 / 2, max(myStruct12.mcd(cycle12_range)) * 0.9, 'Cycle 2', 'HorizontalAlignment', 'center');

% Set x-axis limit to end at the last data point
xlim([1 / 2 64 / 2]);  % Updated limits
hold off;
