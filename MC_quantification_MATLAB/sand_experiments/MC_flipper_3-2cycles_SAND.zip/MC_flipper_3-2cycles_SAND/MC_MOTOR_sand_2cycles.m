%% Initialization
clear;

% Load data
load("/MATLAB Drive/MC_flipper_3cycles_SAND/myStruct12.mat");
myStruct12.name = 'Flipper_data_sand_3cycles';

% Define initial min/max values
position_X_min = 0; 
position_X_max = 289.13;
load_min = 0; 
load_max = 256;

% Get the max/min values of position and load data
position_X_min = min(myStruct12.motor2_position_X_12cycles);
position_X_max = max(myStruct12.motor2_position_X_12cycles);
load_min = min(myStruct12.motor2_load_12cycles);
load_max = max(myStruct12.motor2_load_12cycles);

%% Discretise Test
bins = 100;  % Number of bins for discretization

% Discretize position and load data
myStruct12.discrete_position = discretiseMatrix(myStruct12.motor2_position_X_12cycles, ...
    'min', position_X_min, 'max', position_X_max, 'bins', bins);
myStruct12.discrete_load = discretiseMatrix(myStruct12.motor2_load_12cycles, ...
    'min', load_min, 'max', load_max, 'bins', bins);

%% Run MC quantification
myStruct12.w2 = myStruct12.discrete_position(2:end,:);
myStruct12.w1 = myStruct12.discrete_position(1:end-1,:);
myStruct12.a1 = myStruct12.discrete_load(1:end-1,:);

% Compute MC values
myStruct12.mcw = MC_W1(myStruct12.w2, myStruct12.w1, myStruct12.a1);
myStruct12.mcd = MC_W1_dynamic(myStruct12.w2, myStruct12.w1, myStruct12.a1);

%% Plotting Position, Load, and MC for the First Two Cycles
figure('Position', [100, 100, 800, 600]);

% Define the range for the first two cycles
cycle12_range = 33:96;  % Updated to include from the start to the end of Cycle 2

% Adjusted x-axis values by dividing by 2 for time
time_steps = cycle12_range / 2;

% Plot discrete position and load for the first two cycles
subplot(2,1,1);
hold on;
plot(time_steps, myStruct12.discrete_position(cycle12_range), 'DisplayName', 'Position', 'Color', 'b');
plot(time_steps, myStruct12.discrete_load(cycle12_range), 'DisplayName', 'Load', 'Color', 'r');
xlabel('Time (s)');  % Updated x-label
ylabel('Motor Value');
title('(A) Motor - Sand');
%legend('NumColumns', 1, 'Location', 'northeast', 'Box', 'off');

% Mark the boundary between Cycle 1 and Cycle 2
xline(33 / 2, '--k', 'HandleVisibility', 'off'); % End of Cycle 1
xline(64 / 2, '--k', 'HandleVisibility', 'off'); % End of Cycle 2

% Add boundaries for swing and stance phases at positions 20, 25, 36, and 42
xline(20, '--', 'Color', [0.5 0.5 0.5], 'LineWidth', 1.5, 'HandleVisibility', 'off');
xline(25, '--', 'Color', [0.5 0.5 0.5], 'LineWidth', 1.5, 'HandleVisibility', 'off');
xline(36, '--', 'Color', [0.5 0.5 0.5], 'LineWidth', 1.5, 'HandleVisibility', 'off');
xline(42, '--', 'Color', [0.5 0.5 0.5], 'LineWidth', 1.5, 'HandleVisibility', 'off');

% Add labels "p0" through "p6" between boundaries
% Set Y-position to mid-height of discrete_position data for better visibility
mid_y = (max(myStruct12.discrete_position(cycle12_range)) + min(myStruct12.discrete_position(cycle12_range))) / 3;
text(18.2, mid_y, 'p0', 'HorizontalAlignment', 'center', 'FontSize', 9);
text(22.5, mid_y, 'p1', 'HorizontalAlignment', 'center', 'FontSize', 9);
text(28, mid_y, 'p2', 'HorizontalAlignment', 'center', 'FontSize', 9);
text(34.3, mid_y, 'p3', 'HorizontalAlignment', 'center', 'FontSize', 9);
text(39, mid_y, 'p4', 'HorizontalAlignment', 'center', 'FontSize', 9);
text(44, mid_y, 'p5', 'HorizontalAlignment', 'center', 'FontSize', 9);


% Set x-axis limit to end at the last data point
xlim([33 / 2 96 / 2]);  % Updated limits to include all data
hold off;

% Plot MC values with smoothing for the first two cycles
subplot(2,1,2);
hold on;
plot(time_steps, myStruct12.mcd(cycle12_range), 'DisplayName', 'Actual MC', 'Color', 'b');
plot(time_steps, smooth(myStruct12.mcd(cycle12_range)), 'DisplayName', 'Smooth MC', 'Color', 'g');
xlabel('Time (s)');  % Updated x-label
ylabel('MC Value');
title('(B) MC - Sand');
%legend('NumColumns', 1, 'Location', 'northeast', 'Box', 'off');

% Mark the boundary between Cycle 1 and Cycle 2 in the MC plot
xline(33 / 2, '--k', 'HandleVisibility', 'off'); % End of Cycle 1
xline(64 / 2, '--k', 'HandleVisibility', 'off'); % End of Cycle 2

% Add labels for Cycle 1 and Cycle 2 in the MC plot
text(47 / 2, max(myStruct12.mcd(cycle12_range)) * 0.9, 'Cycle 1', 'HorizontalAlignment', 'center', 'FontSize', 9);
text(77 / 2, max(myStruct12.mcd(cycle12_range)) * 0.9, 'Cycle 2', 'HorizontalAlignment', 'center', 'FontSize', 9);

% Set x-axis limit to end at the last data point
xlim([33 / 2 96 / 2]);  % Updated limits to include all data
hold off;
