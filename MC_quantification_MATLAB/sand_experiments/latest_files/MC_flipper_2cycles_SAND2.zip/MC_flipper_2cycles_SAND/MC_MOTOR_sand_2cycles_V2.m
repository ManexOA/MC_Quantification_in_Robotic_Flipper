%% Initialization
clear;

% Load data
load("/MATLAB Drive/MC_flipper_3-2cycles_SAND/myStruct12.mat");
myStruct12.name = 'Flipper_data_sand_3cycles';

% Define initial min/max values
position_X_min = 0; 
position_X_max = 289.13;
load_min = 0; 
load_max = 256;

% Get the max/min values of position and load data
position_X_min = min(myStruct12.motor2_position_X_12cycles);
position_X_max = max(myStruct12.motor2_position_X_12cycles);
load_min = min(myStruct12.motor2_load_12cycles);
load_max = max(myStruct12.motor2_load_12cycles);

%% Discretise Test
bins = 100;  % Number of bins for discretization

% Discretize position and load data
myStruct12.discrete_position = discretiseMatrix(myStruct12.motor2_position_X_12cycles, ...
    'min', position_X_min, 'max', position_X_max, 'bins', bins);
myStruct12.discrete_load = discretiseMatrix(myStruct12.motor2_load_12cycles, ...
    'min', load_min, 'max', load_max, 'bins', bins);

%% Run MC quantification
myStruct12.w2 = myStruct12.discrete_position(2:end,:);
myStruct12.w1 = myStruct12.discrete_position(1:end-1,:);
myStruct12.a1 = myStruct12.discrete_load(1:end-1,:);

% Compute MC values
myStruct12.mcw = MC_W1(myStruct12.w2, myStruct12.w1, myStruct12.a1);
myStruct12.mcd = MC_W1_dynamic(myStruct12.w2, myStruct12.w1, myStruct12.a1);

%% Plotting Position, Load, and MC for the First Two Cycles
figure('Position', [100, 100, 800, 600]);  % Width: 800, Height: 600

% Define the range for plotting the data
cycle12_range = 1:64;

% Adjusted x-axis values for time
time_steps = cycle12_range / 2;

% Plot discrete position and load for the first two cycles
subplot(2,1,1);
hold on;
if ~isempty(cycle12_range)  % Check if range is valid
    plot(time_steps, myStruct12.discrete_position(cycle12_range), 'DisplayName', 'Position', 'Color', 'b');
    plot(time_steps, myStruct12.discrete_load(cycle12_range), 'DisplayName', 'Load', 'Color', 'r');
else
    warning('Cycle range is empty. No data to plot for discrete position and load.');
end
xlabel('Time (s)', 'FontSize', 11);  % Set font size for x-axis label
ylabel('Motor Value','Position', [-1, 50, 0], 'FontSize', 11);  % Set font size for y-axis label
title('(A) Motor data [Sand]', 'FontSize', 12);  % Set font size for the title

% Increase the size of the tick numbers
ax = gca;  % Get the current axes
set(ax, 'FontSize', 11);  % Set font size for axes ticks
% Mark the boundary between Cycle 1 and Cycle 2
xline(64 / 4, '--k','LineWidth', 0.80, 'HandleVisibility', 'off'); % Adjusted for time steps

% Add boundaries for swing and stance phases at positions 20, 25, 36, and 42
%xline(20, '--', 'Color', [0.5 0.5 0.5], 'LineWidth', 1.5, 'HandleVisibility', 'off');
%xline(25, '--', 'Color', [0.5 0.5 0.5], 'LineWidth', 1.5, 'HandleVisibility', 'off');
%xline(36, '--', 'Color', [0.5 0.5 0.5], 'LineWidth', 1.5, 'HandleVisibility', 'off');
%xline(42, '--', 'Color', [0.5 0.5 0.5], 'LineWidth', 1.5, 'HandleVisibility', 'off');

% Add labels "p0" through "p6" between boundaries
mid_y = (max(myStruct12.discrete_position(cycle12_range)) + ...
         min(myStruct12.discrete_position(cycle12_range))) / 3;
text(2.2, 42, 'Swing', 'HorizontalAlignment', 'center', 'FontSize', 8, 'FontWeight', 'bold', 'Color', [0.5 0.5 0.5]);
text(7.2, 42, 'Stance', 'HorizontalAlignment', 'center', 'FontSize', 8, 'FontWeight', 'bold', 'Color', [0.5 0.5 0.5]);
text(12.2, 42, 'Swing', 'HorizontalAlignment', 'center', 'FontSize',8, 'FontWeight', 'bold', 'Color', [0.5 0.5 0.5]);
%text(18, 50, 'p3', 'HorizontalAlignment', 'center', 'FontSize', 10);
%text(23, 50, 'p4', 'HorizontalAlignment', 'center', 'FontSize', 10);
%text(28, 50, 'p5', 'HorizontalAlignment', 'center', 'FontSize', 10);

% Set x-axis limit to match time steps
xlim([time_steps(1) time_steps(end)]);

% Extend the Y-axis by a small margin (e.g., 10% above the maximum and 10% below the minimum)
y_min = min(myStruct12.discrete_position(cycle12_range));
y_max = max(myStruct12.discrete_position(cycle12_range));
y_margin = 0.05 * (y_max - y_min);  % 10% margin

% Apply the new Y-limits
ylim([y_min - y_margin, y_max + y_margin]);

box on;  % Add top and right lines to the graph

% Highlight the downstroke phase (between 3 and 9) with a background color
% Create a patch for the region
patch([4.5 10 10 4.5], [ax.YLim(1) ax.YLim(1) ax.YLim(2) ax.YLim(2)], 'k', 'FaceAlpha', 0.05, 'EdgeColor', 'none');
patch([20.5 26 26 20.5], [ax.YLim(1) ax.YLim(1) ax.YLim(2) ax.YLim(2)], 'k', 'FaceAlpha', 0.05, 'EdgeColor', 'none');
hold off;

% Plot MC values with smoothing for the first two cycles
subplot(2,1,2);
hold on;
if length(myStruct12.mcd) >= max(cycle12_range)
    plot(time_steps, myStruct12.mcd(cycle12_range), 'DisplayName', 'Actual MC'); % Default colour (Blue)
    plot(time_steps, smooth(myStruct12.mcd(cycle12_range)), 'DisplayName', 'Smooth MC'); % Default colour (Orange)
else
    warning('MC data is insufficient for the selected range.');
end
xlabel('Time (s)', 'FontSize', 11);  % Set font size for x-axis label
ylabel('MC Value','Position', [-1, 2.15, 0], 'FontSize', 11);  % Set font size for y-axis label
title('(B) MC data [Sand]', 'FontSize', 12);  % Set font size for the title

% Increase the size of the tick numbers
ax = gca;  % Get the current axes
set(ax, 'FontSize', 11);  % Set font size for axes ticks
% Mark the boundary between Cycle 1 and Cycle 2 in the MC plot
xline(64 / 4, '--k','LineWidth', 0.80, 'HandleVisibility', 'off'); % Adjusted for time steps

% Add labels for Cycle 1 and Cycle 2 in the MC plot
if ~isempty(cycle12_range)
    max_mcd = max(myStruct12.mcd(cycle12_range));
    text(32 / 4, max_mcd * 0.9, 'Cycle 1', 'HorizontalAlignment', 'center', 'FontSize', 10, 'FontWeight', 'bold', 'Color', [0.5 0.5 0.5]);
    text(24, max_mcd * 0.9, 'Cycle 2', 'HorizontalAlignment', 'center', 'FontSize', 10, 'FontWeight', 'bold', 'Color', [0.5 0.5 0.5]);
end

% Set x-axis limit to match time steps
xlim([time_steps(1) time_steps(end)]);
box on;  % Add top and right lines to the graph


% Manually define the X and Y coordinates for the background color

% First patch: X from 4.5 to 10, Y from 0 to 1.2*max(MC value)
patch([4.5 10 10 4.5], [0 0 1.2*max(myStruct12.mcd) 1.2*max(myStruct12.mcd)], 'k', 'FaceAlpha', 0.05, 'EdgeColor', 'none');

% Second patch: X from 20.5 to 26, Y from 0 to 1.2*max(MC value)
patch([20.5 26 26 20.5], [0 0 1.2*max(myStruct12.mcd) 1.2*max(myStruct12.mcd)], 'k', 'FaceAlpha', 0.05, 'EdgeColor', 'none');
hold off;

