%% Initialization
% This is to compute MC on the real robot with a 3 mm blade leg, both actuated 
% Key difference is that the bin size is 100

clear;

% Load data
load("/MATLAB Drive/MC_flipper_3cycles_WATER/myStruct_water10.mat");
% Name our dataset
myStruct_water10.name = 'Flipper_data_water_3cycles';

%% 1. Step: Extract min/max values for each column that will be used
% Define initial min/max values
position_X_min  = 0; 
position_X_max = 289.13;
load_min = 0; 
load_max = 256;

% Initialize string for output
real_string = '';

% Assuming myStruct is populated with data from crawling_data.mat
% Uncomment the next lines to load data into myStruct if needed
% myStruct.motor2_position_X  = position_X_crawl(:,31); % Joint angle of hip
% myStruct.motor2_load        = load_crawl(:,31); % Load data

% Get the max/min values of position data
position_X_min = min(myStruct_water10.motor2_position_Z_10cycles_WATER);
position_X_max = max(myStruct_water10.motor2_position_Z_10cycles_WATER);
% Get the max/min values of load data
load_min = min(myStruct_water10.motor2_load_10cycles_WATER);
load_max = max(myStruct_water10.motor2_load_10cycles_WATER);

real_string = [real_string 'Domains\n' ...
    sprintf('  Position:        %f, %f\n', position_X_min, position_X_max) ...
    sprintf('  Load:        %f, %f\n', load_min, load_max)];

%% Discretise Test
bins = 370;  % Number of bins for discretization
fprintf('Bins = %d\n', bins)

% Call the discretiseMatrix function for position and load
myStruct_water10.discrete_position = discretiseMatrix(myStruct_water10.motor2_position_Z_10cycles_WATER, ...
    'min', position_X_min, ...
    'max', position_X_max, ...
    'bins', bins);

myStruct_water10.discrete_load = discretiseMatrix(myStruct_water10.motor2_load_10cycles_WATER, ...
    'min', load_min, ...
    'max', load_max, ...
    'bins', bins);


%% Visualize bins:
fprintf('Discrete Position:\n');
disp(myStruct_water10.discrete_position);

fprintf('Discrete Load:\n');
disp(myStruct_water10.discrete_load);

%% run MC quantification
% 

fprintf('Working on file %s\n', myStruct_water10.name)

myStruct_water10.w2= myStruct_water10.discrete_position(2:end,:);
myStruct_water10.w1 = myStruct_water10.discrete_position(1:end-1,:);

myStruct_water10.a1 = myStruct_water10.discrete_load(1:end-1,:);
%%
%Total MC
myStruct_water10.mcw  = MC_W1(myStruct_water10.w2, myStruct_water10.w1, myStruct_water10.a1);
fprintf('MC_W %f\n', myStruct_water10.mcw);
%%
%Dynamic MC
myStruct_water10.mcd  = MC_W1_dynamic(myStruct_water10.w2, myStruct_water10.w1, myStruct_water10.a1);
mean(myStruct_water10.mcd)
%%
%plotting

plot(myStruct_water10.discrete_position)
title ('Position and Load')
hold on;
plot(myStruct_water10.discrete_load);
hold off;
plot(myStruct_water10.mcd)
hold on;
plot (smooth(myStruct_water10.mcd))
legend('actual MC', 'smooth MC')
title ('MC_Water_3cycles');