%% Initialization
clear;

% Load data
load("/MATLAB Drive/MC_flipper_3cycles_WATER/myStruct_water10.mat");
myStruct_water10.name = 'Flipper_data_water_3cycles';

% Define initial min/max values
position_X_min  = 0; 
position_X_max = 289.13;
load_min = 0; 
load_max = 256;

% Get min/max values of position data
position_X_min = min(myStruct_water10.motor2_position_Z_10cycles_WATER);
position_X_max = max(myStruct_water10.motor2_position_Z_10cycles_WATER);
% Get min/max values of load data
load_min = min(myStruct_water10.motor2_load_10cycles_WATER);
load_max = max(myStruct_water10.motor2_load_10cycles_WATER);

%% Discretise Test
bins = 110;  % Number of bins for discretization
myStruct_water10.discrete_position = discretiseMatrix(myStruct_water10.motor2_position_Z_10cycles_WATER, ...
    'min', position_X_min, ...
    'max', position_X_max, ...
    'bins', bins);

myStruct_water10.discrete_load = discretiseMatrix(myStruct_water10.motor2_load_10cycles_WATER, ...
    'min', load_min, ...
    'max', load_max, ...
    'bins', bins);

%% Run MC quantification
myStruct_water10.w2 = myStruct_water10.discrete_position(2:end,:);
myStruct_water10.w1 = myStruct_water10.discrete_position(1:end-1,:);
myStruct_water10.a1 = myStruct_water10.discrete_load(1:end-1,:);

myStruct_water10.mcw = MC_W1(myStruct_water10.w2, myStruct_water10.w1, myStruct_water10.a1);
myStruct_water10.mcd = MC_W1_dynamic(myStruct_water10.w2, myStruct_water10.w1, myStruct_water10.a1);

%% Plotting only the first cycle
figure;

% Define the range for the first cycle
cycle1_range = 1:35;

% Plot discrete position and load for the first cycle
subplot(2,1,1);
plot(myStruct_water10.discrete_position(cycle1_range), 'DisplayName', 'Position');
hold on;
plot(myStruct_water10.discrete_load(cycle1_range), 'DisplayName', 'Load');
xlabel('Time Step');
ylabel('Value');
title('Position and Load - Cycle 1');
legend('NumColumns', 1, 'Location', 'northeast', 'Box', 'off');

% Add label for Cycle 1
text(18, max(myStruct_water10.discrete_position(cycle1_range)) * 0.9, 'Cycle 1', 'HorizontalAlignment', 'center');

hold off;

% Plot MC values with smoothing for the first cycle
subplot(2,1,2);
plot(myStruct_water10.mcd(cycle1_range), 'DisplayName', 'Actual MC');
hold on;
plot(smooth(myStruct_water10.mcd(cycle1_range)), 'DisplayName', 'Smooth MC');
xlabel('Time Step');
ylabel('MC Value');
title('MC_Water - Cycle 1');
legend('NumColumns', 1, 'Location', 'northeast', 'Box', 'off');

% Add label for Cycle 1 in the MC plot
text(18, max(myStruct_water10.mcd(cycle1_range)) * 0.9, 'Cycle 1', 'HorizontalAlignment', 'center');

hold off;
