

% Assume vector1 and vector2 are your imported 31x1 column vectors
vector1 = MOTOR2_Position_X_;  % Your first column vector (31x1)
vector2 = MOTOR2_load ;  % Your second column vector (31x1)

% Create a structure with two fields, assigning each vector to a field
myStruct = struct('motor2_position_X_12cycles', vector1, 'motor2_load_12cycles', vector2);
