%% Initialization
clear;

% Load data
load("/MATLAB Drive/MC_flipper_3cycles_WATER/myStruct_water10.mat");
myStruct_water10.name = 'Flipper_data_water_3cycles';

% Define initial min/max values
position_X_min  = 0; 
position_X_max = 289.13;
load_min = 0; 
load_max = 256;

% Get min/max values of position data
position_X_min = min(myStruct_water10.motor2_position_Z_10cycles_WATER);
position_X_max = max(myStruct_water10.motor2_position_Z_10cycles_WATER);
% Get min/max values of load data
load_min = min(myStruct_water10.motor2_load_10cycles_WATER);
load_max = max(myStruct_water10.motor2_load_10cycles_WATER);

%% Discretise Test
bins = 110;  % Number of bins for discretization
myStruct_water10.discrete_position = discretiseMatrix(myStruct_water10.motor2_position_Z_10cycles_WATER, ...
    'min', position_X_min, ...
    'max', position_X_max, ...
    'bins', bins);

myStruct_water10.discrete_load = discretiseMatrix(myStruct_water10.motor2_load_10cycles_WATER, ...
    'min', load_min, ...
    'max', load_max, ...
    'bins', bins);

%% Run MC quantification
myStruct_water10.w2 = myStruct_water10.discrete_position(2:end,:);
myStruct_water10.w1 = myStruct_water10.discrete_position(1:end-1,:);
myStruct_water10.a1 = myStruct_water10.discrete_load(1:end-1,:);

myStruct_water10.mcw = MC_W1(myStruct_water10.w2, myStruct_water10.w1, myStruct_water10.a1);
myStruct_water10.mcd = MC_W1_dynamic(myStruct_water10.w2, myStruct_water10.w1, myStruct_water10.a1);

%% Plotting Load and Smooth MC for the First Two Cycles with Dual Y-Axes
figure;
figure('Position', [100, 100, 800, 300]);

% Define the range for the first two cycles
cycle12_range = 1:71;

% Plot Smooth MC on the left y-axis
yyaxis left;
plot(smooth(myStruct_water10.mcd(cycle12_range)), 'DisplayName', 'Smooth MC', 'Color', 'b');
ylabel('Smooth MC Value');
xlabel('Time Step (500ms)');
%title('Load and Smooth MC - ');

% Plot Load on the right y-axis
yyaxis right;
plot(myStruct_water10.discrete_load(cycle12_range), 'DisplayName', 'Load', 'Color', 'r');
ylabel('Load Value');

% Mark the boundary between Cycle 1 and Cycle 2
xline(35, '--k', 'HandleVisibility', 'off'); % End of Cycle 1

% Set x-axis limit to end at the last data point
xlim([1 71]);

% Adjust y-axis limits to allow space for the labels at the top
yyaxis left; % Activate left y-axis to get its limits
ylim_left = ylim; % Get current y-axis limits for left side
ylim([ylim_left(1), ylim_left(2) * 1.1]); % Expand top limit by 10%

% Add labels for Cycle 1 and Cycle 2 at the top of the graph, outside data range
text(18, ylim_left(2) * 1.05, 'Cycle 1', ...
    'HorizontalAlignment', 'center', 'Color', 'k', 'FontSize', 10, 'FontWeight', 'bold');
text(54, ylim_left(2) * 1.05, 'Cycle 2', ...
    'HorizontalAlignment', 'center', 'Color', 'k', 'FontSize', 10, 'FontWeight', 'bold');

hold off;
