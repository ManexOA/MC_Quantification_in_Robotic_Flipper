%% Initialization
clear;

% Load data
load("/MATLAB Drive/MC_flipper_3cycles_WATER/myStruct_water10.mat");
myStruct_water10.name = 'Flipper_data_water_3cycles';

% Define initial min/max values
position_X_min  = 0; 
position_X_max = 289.13;
load_min = 0; 
load_max = 256;

% Get min/max values of position data
position_X_min = min(myStruct_water10.motor2_position_Z_10cycles_WATER);
position_X_max = max(myStruct_water10.motor2_position_Z_10cycles_WATER);
% Get min/max values of load data
load_min = min(myStruct_water10.motor2_load_10cycles_WATER);
load_max = max(myStruct_water10.motor2_load_10cycles_WATER);

%% Discretise Test
bins = 110;  % Number of bins for discretization
myStruct_water10.discrete_position = discretiseMatrix(myStruct_water10.motor2_position_Z_10cycles_WATER, ...
    'min', position_X_min, ...
    'max', position_X_max, ...
    'bins', bins);

myStruct_water10.discrete_load = discretiseMatrix(myStruct_water10.motor2_load_10cycles_WATER, ...
    'min', load_min, ...
    'max', load_max, ...
    'bins', bins);

%% Run MC quantification
myStruct_water10.w2 = myStruct_water10.discrete_position(2:end,:);
myStruct_water10.w1 = myStruct_water10.discrete_position(1:end-1,:);
myStruct_water10.a1 = myStruct_water10.discrete_load(1:end-1,:);

myStruct_water10.mcw = MC_W1(myStruct_water10.w2, myStruct_water10.w1, myStruct_water10.a1);
myStruct_water10.mcd = MC_W1_dynamic(myStruct_water10.w2, myStruct_water10.w1, myStruct_water10.a1);

%% Plotting (3 cycles)
figure;

% Plot discrete position and load
subplot(2,1,1);
plot(myStruct_water10.discrete_position, 'DisplayName', 'Position');
hold on;
plot(myStruct_water10.discrete_load, 'DisplayName', 'Load');
xlabel('Time Step');
ylabel('Value');
title('Position and Load in water');
legend();

% Mark cycle boundaries with simple vertical lines (not included in legend)
xline(35, '--k', 'HandleVisibility', 'off'); % End of Cycle 1
xline(71, '--k', 'HandleVisibility', 'off'); % End of Cycle 2
xline(105, '--k', 'HandleVisibility', 'off'); % End of Cycle 3

% Add labels slightly above data and within the plot for each cycle
text(18, max(myStruct_water10.discrete_position) * 0.9, 'Cycle 1', 'HorizontalAlignment', 'center');
text(54, max(myStruct_water10.discrete_position) * 0.9, 'Cycle 2', 'HorizontalAlignment', 'center');
text(88, max(myStruct_water10.discrete_position) * 0.9, 'Cycle 3', 'HorizontalAlignment', 'center');

hold off;

% Plot MC values with smoothing
subplot(2,1,2);
plot(myStruct_water10.mcd, 'DisplayName', 'Actual MC');
hold on;
plot(smooth(myStruct_water10.mcd), 'DisplayName', 'Smooth MC');
xlabel('Time Step');
ylabel('MC Value');
title('MC_Water_3cycles');
legend();

% Mark cycle boundaries with simple vertical lines (not included in legend)
xline(35, '--k', 'HandleVisibility', 'off'); % End of Cycle 1
xline(71, '--k', 'HandleVisibility', 'off'); % End of Cycle 2
xline(105, '--k', 'HandleVisibility', 'off'); % End of Cycle 3

% Add labels slightly above data and within the plot for each cycle
text(18, max(myStruct_water10.mcd) * 0.9, 'Cycle 1', 'HorizontalAlignment', 'center');
text(54, max(myStruct_water10.mcd) * 0.9, 'Cycle 2', 'HorizontalAlignment', 'center');
text(88, max(myStruct_water10.mcd) * 0.9, 'Cycle 3', 'HorizontalAlignment', 'center');

hold off;

