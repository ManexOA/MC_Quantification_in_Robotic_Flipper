%% Initialization
clear;

% Load data
load("/MATLAB Drive/MC_flipper_3cycles_WATER/myStruct_water10.mat");
myStruct_water10.name = 'Flipper_data_water_3cycles';

% Define initial min/max values
position_X_min  = 0; 
position_X_max = 289.13;
load_min = 0; 
load_max = 256;

% Get min/max values of position data
position_X_min = min(myStruct_water10.motor2_position_Z_10cycles_WATER);
position_X_max = max(myStruct_water10.motor2_position_Z_10cycles_WATER);
% Get min/max values of load data
load_min = min(myStruct_water10.motor2_load_10cycles_WATER);
load_max = max(myStruct_water10.motor2_load_10cycles_WATER);

%% Discretise Test
bins = 100;  % Number of bins for discretization
myStruct_water10.discrete_position = discretiseMatrix(myStruct_water10.motor2_position_Z_10cycles_WATER, ...
    'min', position_X_min, ...
    'max', position_X_max, ...
    'bins', bins);

myStruct_water10.discrete_load = discretiseMatrix(myStruct_water10.motor2_load_10cycles_WATER, ...
    'min', load_min, ...
    'max', load_max, ...
    'bins', bins);

%% Run MC quantification
myStruct_water10.w2 = myStruct_water10.discrete_position(2:end,:);
myStruct_water10.w1 = myStruct_water10.discrete_position(1:end-1,:);
myStruct_water10.a1 = myStruct_water10.discrete_load(1:end-1,:);

myStruct_water10.mcw = MC_W1(myStruct_water10.w2, myStruct_water10.w1, myStruct_water10.a1);
myStruct_water10.mcd = MC_W1_dynamic(myStruct_water10.w2, myStruct_water10.w1, myStruct_water10.a1);

%% Plotting only the first two cycles
figure;

% Define the range for the first two cycles
cycle12_range = 1:71;

% Adjusted x-axis values by dividing by 2
time_steps = (1:71) / 2; 

% Plot discrete position and load for the first two cycles
subplot(2,1,1);
plot(time_steps, myStruct_water10.discrete_position(cycle12_range), 'DisplayName', 'Position');
hold on;
plot(time_steps, myStruct_water10.discrete_load(cycle12_range), 'DisplayName', 'Load');
xlabel('Time (s)');  % Updated x-label
ylabel('Motor Value');
title('(A) Motor - Water');
%legend('NumColumns', 1, 'Location', 'northeast', 'Box', 'off');

% Mark the boundary between Cycle 1 and Cycle 2
xline(35 / 2, '--k', 'HandleVisibility', 'off'); % End of Cycle 1

% Add boundaries for swing and stance phases at positions 20, 25, 36, and 42, with HandleVisibility off
xline(3, '--', 'Color', [0.5 0.5 0.5], 'LineWidth', 1.5, 'HandleVisibility', 'off');
xline(9, '--', 'Color', [0.5 0.5 0.5], 'LineWidth', 1.5, 'HandleVisibility', 'off');
xline(20, '--', 'Color', [0.5 0.5 0.5], 'LineWidth', 1.5, 'HandleVisibility', 'off');
xline(27, '--', 'Color', [0.5 0.5 0.5], 'LineWidth', 1.5, 'HandleVisibility', 'off');

% Add labels "p0" through "p6" between boundaries
% Set Y-position to mid-height of discrete_position data for better visibility
mid_y = (max(myStruct_water10.discrete_position(cycle12_range)) + min(myStruct_water10.discrete_position(cycle12_range))) / 1.5;
mid_y2 = (max(myStruct_water10.discrete_position(cycle12_range)) + min(myStruct_water10.discrete_position(cycle12_range))) / 1.25;

text(2, mid_y2, 'p0', 'HorizontalAlignment', 'center', 'FontSize', 9); % Adjust font size as needed
text(5.2, mid_y, 'p1', 'HorizontalAlignment', 'center', 'FontSize', 9); % Adjust font size as needed
text(13, mid_y, 'p2', 'HorizontalAlignment', 'center', 'FontSize', 9); % Adjust font size as needed
text(18.5, mid_y2, 'p3', 'HorizontalAlignment', 'center', 'FontSize', 9); % Adjust font size as needed
text(23, mid_y, 'p4', 'HorizontalAlignment', 'center', 'FontSize', 9); % Adjust font size as needed
text(30, mid_y, 'p5', 'HorizontalAlignment', 'center', 'FontSize', 9); % Adjust font size as needed

% Set x-axis limit to end at the last data point
xlim([1 / 2 71 / 2]);  % Updated limits
hold off;

% Plot MC values with smoothing for the first two cycles
subplot(2,1,2);
plot(time_steps, myStruct_water10.mcd(cycle12_range), 'DisplayName', 'Actual MC');
hold on;
plot(time_steps, smooth(myStruct_water10.mcd(cycle12_range)), 'DisplayName', 'Smooth MC');
xlabel('Time (s)');  % Updated x-label
ylabel('MC Value');
title('(B) MC - Water');
%legend('NumColumns', 1, 'Location', 'northeast', 'Box', 'off');

% Mark the boundary between Cycle 1 and Cycle 2 in the MC plot
xline(35 / 2, '--k', 'HandleVisibility', 'off'); % End of Cycle 1

% Add labels for Cycle 1 and Cycle 2 in the MC plot
text(18 / 2, max(myStruct_water10.mcd(cycle12_range)) * 0.9, 'Cycle 1', 'HorizontalAlignment', 'center', 'FontSize', 9);
text(54 / 2, max(myStruct_water10.mcd(cycle12_range)) * 0.9, 'Cycle 2', 'HorizontalAlignment', 'center', 'FontSize', 9);

% Set x-axis limit to end at the last data point
xlim([1 / 2 71 / 2]);  % Updated limits
hold off;
