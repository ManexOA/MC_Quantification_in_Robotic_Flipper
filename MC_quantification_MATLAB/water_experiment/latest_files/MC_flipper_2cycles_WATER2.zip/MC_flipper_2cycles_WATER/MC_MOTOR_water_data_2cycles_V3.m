%% Initialization
clear;

% Load data
load("/MATLAB Drive/MC_flipper_3cycles_WATER/myStruct_water10.mat");
myStruct_water10.name = 'Flipper_data_water_3cycles';

% Define initial min/max values
position_X_min  = 0; 
position_X_max = 289.13;
load_min = 0; 
load_max = 256;

% Get min/max values of position data
position_X_min = min(myStruct_water10.motor2_position_Z_10cycles_WATER);
position_X_max = max(myStruct_water10.motor2_position_Z_10cycles_WATER);
% Get min/max values of load data
load_min = min(myStruct_water10.motor2_load_10cycles_WATER);
load_max = max(myStruct_water10.motor2_load_10cycles_WATER);

%% Discretise Test
bins = 100;  % Number of bins for discretization
myStruct_water10.discrete_position = discretiseMatrix(myStruct_water10.motor2_position_Z_10cycles_WATER, ...
    'min', position_X_min, ...
    'max', position_X_max, ...
    'bins', bins);

myStruct_water10.discrete_load = discretiseMatrix(myStruct_water10.motor2_load_10cycles_WATER, ...
    'min', load_min, ...
    'max', load_max, ...
    'bins', bins);

%% Run MC quantification
myStruct_water10.w2 = myStruct_water10.discrete_position(2:end,:);
myStruct_water10.w1 = myStruct_water10.discrete_position(1:end-1,:);
myStruct_water10.a1 = myStruct_water10.discrete_load(1:end-1,:);

myStruct_water10.mcw = MC_W1(myStruct_water10.w2, myStruct_water10.w1, myStruct_water10.a1);
myStruct_water10.mcd = MC_W1_dynamic(myStruct_water10.w2, myStruct_water10.w1, myStruct_water10.a1);

%% Plotting only the first two cycles
figure('Position', [100, 100, 800, 600]);  % Width: 800, Height: 600

% Define the range for the first two cycles
cycle12_range = 1:71;

% Adjusted x-axis values by dividing by 2
time_steps = (1:71) / 2; 

% Plot discrete position and load for the first two cycles
subplot(2,1,1);
plot(time_steps, myStruct_water10.discrete_position(cycle12_range), 'DisplayName', 'Position', 'Color', 'b');
hold on;
plot(time_steps, myStruct_water10.discrete_load(cycle12_range), 'DisplayName', 'Load', 'Color', 'r');
xlabel('Time (s)', 'FontSize', 11);  % Set font size for x-axis label
% Adjust the position of the y-axis label (move it closer to the plot)
ylabel('Motor Value', 'Position', [-1, 50, 0], 'FontSize', 11);  % Change [-1, 5, 0] to adjust position
title('(A) Motor data [Water]', 'FontSize', 12);  % Set font size for the title

% Increase the size of the tick numbers
ax = gca;  % Get the current axes
set(ax, 'FontSize', 11);  % Set font size for axes ticks

% Mark the boundary between Cycle 1 and Cycle 2
xline(36 / 2, '--k', 'LineWidth', 0.80,'HandleVisibility', 'off'); % End of Cycle 1

% Add boundaries for swing and stance phases at positions 20, 25, 36, and 42
%xline(3, '--', 'Color', [0.5 0.5 0.5], 'LineWidth', 0.5, 'HandleVisibility', 'off');
%xline(9, '--', 'Color', [0.5 0.5 0.5], 'LineWidth', 0.5, 'HandleVisibility', 'off');
%xline(20, '--', 'Color', [0.5 0.5 0.5], 'LineWidth', 0.5, 'HandleVisibility', 'off');
%xline(27, '--', 'Color', [0.5 0.5 0.5], 'LineWidth', 0.5, 'HandleVisibility', 'off');

% Add labels "Downstroke" and "Recovery" with grey color
text(5.8, 94, 'Power stroke', 'HorizontalAlignment', 'center', 'FontSize', 8,'FontWeight', 'bold', 'Color', [0.5 0.5 0.5]); % Grey color
text(14, 94, 'Recovery', 'HorizontalAlignment', 'center', 'FontSize', 8,'FontWeight', 'bold', 'Color', [0.5 0.5 0.5]); % Grey color

% Set x-axis limit to end at the last data point
xlim([1 / 2 71 / 2]);  % Updated limits
box on;  % Add top and right lines to the graph

% Highlight the downstroke phase (between 3 and 9) with a background color
% Create a patch for the region
patch([3 9 9 3], [ax.YLim(1) ax.YLim(1) ax.YLim(2) ax.YLim(2)], 'k', 'FaceAlpha', 0.05, 'EdgeColor', 'none');
patch([20.5 26.5 26.5 20.5], [ax.YLim(1) ax.YLim(1) ax.YLim(2) ax.YLim(2)], 'k', 'FaceAlpha', 0.05, 'EdgeColor', 'none');


hold off;

% Plot MC values with smoothing for the first two cycles
subplot(2,1,2);
plot(time_steps, myStruct_water10.mcd(cycle12_range), 'DisplayName', 'Actual MC','Color','[0.4940, 0.1840, 0.5560]'); % Purple line colour
hold on;
plot(time_steps, smooth(myStruct_water10.mcd(cycle12_range)), 'DisplayName', 'Smooth MC'); % Orange colour(default)
xlabel('Time (s)', 'FontSize', 11);  % Set font size for x-axis label
ylabel('MC Value', 'Position', [-1, 3, 0],'FontSize', 11);  % Set font size for y-axis label
title('(B) MC [Water]', 'FontSize', 12);  % Set font size for the title

% Increase the size of the tick numbers
ax = gca;  % Get the current axes
set(ax, 'FontSize', 11);  % Set font size for axes ticks

% Mark the boundary between Cycle 1 and Cycle 2 in the MC plot
xline(36 / 2, '--k', 'LineWidth', 0.80,'HandleVisibility', 'off'); % End of Cycle 1

% Add labels for Cycle 1 and Cycle 2 in the MC plot
text(18 / 2, max(myStruct_water10.mcd(cycle12_range)) * 0.9, 'Cycle 1', 'HorizontalAlignment', 'center', 'FontSize',10, 'FontWeight', 'bold', 'Color', [0.5 0.5 0.5]);
text(54 / 2, max(myStruct_water10.mcd(cycle12_range)) * 0.9, 'Cycle 2', 'HorizontalAlignment', 'center', 'FontSize', 10, 'FontWeight', 'bold','Color', [0.5 0.5 0.5]);

% Set x-axis limit to end at the last data point
xlim([1 / 2 71 / 2]);  % Updated limits
box on;  % Add top and right lines to the graph

% Highlight the downstroke phase (between 3 and 9) with a background color
% Create a patch for the region
patch([3 9 9 3], [ax.YLim(1) ax.YLim(1) ax.YLim(2) ax.YLim(2)], 'k', 'FaceAlpha', 0.05, 'EdgeColor', 'none');
patch([20.5 26.5 26.5 20.5], [ax.YLim(1) ax.YLim(1) ax.YLim(2) ax.YLim(2)], 'k', 'FaceAlpha', 0.05, 'EdgeColor', 'none');

hold off;
